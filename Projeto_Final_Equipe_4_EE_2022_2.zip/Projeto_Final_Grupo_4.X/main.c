/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "ledMatrix.h"
#include "math.h"

/*************************************************************************
**************************************************************************
**************************************************************************
****                 Universidade de Bras�lia FGA                     ****
**************************************************************************
************************************************************************** 
****                 Eletr�nica Embarcada - FGA0096                   ****
**************************************************************************     
**************************************************************************
**** PROF.: GUILLERMO ALVAREZ BESTARD                                 ****
**** Alunos: JO�O PAULO DIAS                  Matr�cula: 170146324    ****
****         LEONI GABRIEL SILVESTRE          Matr�cula: 170108112    ****
****         LUCAS PINHEIRO DE SOUZA          Matr�cula: 160156866    ****
****         RODRIGO RIBEIRO LOPES TRINDADE   Matr�cula: 170113922    **** 
**************************************************************************
************************************************************************** 
*************************************************************************/


/*

 ADC       -        Coleta informa��es sobre a temperatura
 CCP3(PWM) -        Define o ciclo �til da tens�o de alimenta��o do motor
 CMP1      -        Utilizado para identificar a posi��o do elevador pelo sensor hall S3
 CMP2      -        Utilizado para identificar a posi��o do elevador pelo sensor hall S4
 EUSART    -        Comunicaca��o serial com PC
 FVR       -        Tens�o de refer�ncia para a medi��o de temperatura e para os comparadores
 MEMORY    -        Armazena os valores para ser exibido no LED
 TIMER1    -        Utilizado para o CCP4
 TIMER2    -        Usado para o PWM
 TIMER4    -        Utilizado para que comunica��o serial
 * 
 */

#define pwm_dc     193                 // Dutycycle 
#define pulse      .837                // 180/215 rela��o entre mm e pulsos

float position;                        // float para calcular a posi��o
int motor_state   = 0,                // vari�vel para definir o estado do motor 
    floor_current = 0,                //  Variavel para armazenar o andar atual/
    pulses        = 0,                //  Conta os pulsos enviados pelo encoder para calcular a posi��o do elevador
    speed         = 0,                //  Calcula a velocidade do motor
    temperature   = 0,                //  Calcula a temperatura do motor
    floor_req     = 0;                //  Variavel que armazena o Andar solicitado

uint16_t colect_value =0,              // Coleta o valor do encoder
         v;                            // Coleta o valor do converso anal�gico para digital
uint8_t txBytes[4],                    // Armazena os bytes que ser�o transmitidos
        LEDs[8],                       // Armaazena os bits de cada coluna da matriz de LEDs
        rxByte;                 
         
/*
 motor_state = 0 stop
             = 1 up
             = 2 down
 */
  
    /*Fun��es para os LEDs*/


// Fun��o que gera os valores dos bits para a Matriz de LEDs que representam os simbolos e mostra na Matriz de LEds
void makeMatrix(){
    updateMatrix(0,floor_current); // Gera os bits para representar os numeros
    updateMatrix(4,(motor_state+5)); //gera os bits para representar o simbolo de subida, descida ou parado
    sendMatrix(); // Impime os simbolos na matriz de LEDs
}

//Fun��o que impime os simbolos na matriz de LEDs
void led(void){
    for(int i = 0;i<8;i++){
        txMAX7219(i+1,LEDs[i]);
    }
}
//Fun��o que gera os valores dos bits para a Matriz de LEDs que representam os simbolos
void show_led(){
    
    for(int i =0;i<4;i++){
        LEDs[i] = DATAEE_ReadByte(4*(floor_current+1)+i); // Gera os bits para representar os numeros
        LEDs[i+4] = DATAEE_ReadByte(4*(motor_state+6)+i); //gera os bits para representar o simbolo de subida, descida ou parado
    }
    led();
    
    
}


    /*Fun��o para o encoder*/



void Encoder(uint16_t encoder_value){
    
    colect_value = encoder_value; //Coleta o valor obtido pela captura no encoder
    if(motor_state == 1 && pulses < 215 ){ // Verifica se est� subindo e se n�o chegou no valor m�ximo
        pulses ++; // Incrementa o n�mero de pulsos
    }
    else if(motor_state == 2 && pulses >0){ // Verifica se est� descendo e se n�o chegou no valor m�nimo
        pulses --; //Decrementa o n�mero de pulsos
    }
    else if(motor_state==0){ //Verifica se o motor est� parado
        speed = 0;// Zera a velocidade
    }
    
    else {
        pulses = 0; // Estado inicial
    }
    TMR1_WriteTimer(0); //Zera o timer do encoder
}

//Fun��o para comunica��o serial, onde os dados ser�o enviados

void ser_com(){
    
    txBytes[0] = 0xB3 && ((uint8_t)motor_state<<4 || (0b10000000)||((uint8_t)floor_current)); //Armazena o estado do motor nos bits 4 e 5 e o andar nos bit 0 e 1. Os demais s�o zerados
    txBytes[1] = 0x7F && (uint8_t)(position/2); // Armazena a posi��o do elevador com o valor dos bits deslocado para direita
    txBytes[2] = 0x7F && (uint8_t)(speed*4);// Armazena a velocidade do elevador com o valor dos bits deslocado para esquerda em duas posi��e
    txBytes[3] = 0x7F && (uint8_t)(temperature*2);// Armazena a posi��o do elevador com o valor dos bits deslocado para esquerda em uma posi��o
    
    for(int i=0; i<4;i++){
        EUSART_Write(txBytes[i]); // Envia os dados
    }
    
}

/*Fun��o que controla o elevador*/

void motion(void){
    
    // Controla o movimento do elevador
    if (floor_current != floor_req){ //Se o elevador n�o chegou ao andar continua o movimento e o motor continua ativo
        PWM3_LoadDutyValue(pwm_dc);
        
    }
    else { // Caso tenha chegado, o elevador para e o motor � desligado 
        PWM3_LoadDutyValue(0);
        motor_state = 0;
        __delay_ms(2000); // Espera de dois segundos pra pessoa poder sair.
        
    }
}


// Fun��o que controla o movimento do elevador
void ctrl(){
    // RA7 = DIR
    if (floor_current<floor_req){ //Verifica se o elevador est� abaixo do desejado
        if (motor_state == 2){ // Verifica se estava descendo
            
            PWM3_LoadDutyValue(0); //Desliga o motor para desacelerar e evitar danos
            __delay_ms(500); // Espera 500 ms
            
        }
        
        IO_RA7_SetHigh(); // Muda o sentido da rota��o, fazendo subir
        motor_state = 1; // Muda o estado do motor para subindo
        
    }
    else if(floor_current>floor_req){//Verifica se est� acima do andar desejado
        if(motor_state == 1){// Verifica se estava subindo
        
            PWM3_LoadDutyValue(0); // Desliga o motor para desacelerar
            __delay_ms(500);// Espera 500 ms
            
        }
        
        IO_RA7_SetLow(); //Muda o sentido da rota��o, fazendo descer
        motor_state = 2; // Muda o estado do motor para descendo
    }
    
    else if (floor_current==floor_req && floor_current!=0){ // Verifica se est� no andar desejado e este n�o � o primeiro andar
        if(motor_state == 0){ // Verifica se est� parado
            
            PWM3_LoadDutyValue(0); // Certifica de desligar o motor
            __delay_ms(2000); // Espera 2 s para Pessoa sair
        }
        IO_RA7_SetLow(); // Muda o sentido da rota��o fazendo descer
        motor_state = 2; //  Muda o estado do motor para descendo
        floor_req = 0; // Ativa o primeiro andar como o andar desejado
        
    }
    
    motion();    // Chama a fun��o que controla o elevador
    
    
}

// Fun��o que ser� ativada quando o elevador estiver no primeiro andar
void sensor1_set(void) {

    // Add custom IOCBF6 code

    // Call the interrupt handler for the callback registered at runtime

    floor_current = 0; // Identifica que est� no primeiro andar
    pulses = 0; // Zera os pulsos
    ctrl(); // Solicita o controle
    //makeMatrix(); // Exibe o andar e estado do motor
 
}

// Fun��o que ser� ativada quando o elevador estiver no primeiro andar
void sensor2_set(void) {

    // Add custom IOCBF7 code

    // Call the interrupt handler for the callback registered at runtime
    floor_current = 1; //Identifica que est� no segundo andar
    ctrl(); // Solicita o controle do elevador
    //makeMatrix(); // Exibe o andar e estado do motor

 
}

// Fun��o que ser� ativada quando o elevador estiver no primeiro andar
void sensor3_set(void)
{   
    
    // Call the interrupt handler for the callback registered at runtime
    floor_current = 2;//Identifica que est� no terceiro andar
    ctrl();// Solicita o controle do elevador
    //makeMatrix(); // Exibe o andar e estado do motor
    
    // clear the CMP1 interrupt flag
 
}


// Fun��o que ser� ativada quando o elevador estiver no primeiro andar
void sensor4_set(void)
{
    

    
    floor_current = 3;//Identifica que est� no quarto andar
    pulses = 215; // Armazena o valor m�ximo dos pulsos
    ctrl(); // Solicita o controle do elevador
    //makeMatrix(); // Exibe o andar e estado do motor
    // clear the CMP2 interrupt flag
 
}

// Fun��o que ser� ativada quando o sistema for iniciado para indentifica onde o elevador se encontra
void current_floor(){
//Verificando sensor S1
    if(IO_RB6_GetValue()==1){
        floor_current = 0;                
    }
//Verificando sensor S2
    else if(IO_RB7_GetValue()==1){
        floor_current = 1;
    }
//Verificando sensor S3
    else if(CMP1_GetOutputStatus()==1){
        floor_current = 2;
    }
//Verificando sensor S4
    else if(CMP2_GetOutputStatus()==1){
        floor_current = 3;
    }    
}


void main(void)
{
    // initialize the devices
    SYSTEM_Initialize();
      

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();
    
    //Coleta os dados fornecidos pelo encoder
    CCP4_SetCallBack(Encoder); 
    
    // Outras Interrup��es
    TMR4_SetInterruptHandler(ser_com);
    IOCBF6_SetInterruptHandler(sensor1_set);
    IOCBF7_SetInterruptHandler(sensor2_set);
    //CMP1_SetInterruptHandler(sensor3_set);   
    //CMP2_SetInterruptHandler(sensor4_set);
    
    
       

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    //Inicia a matriz de LEDs
    LATBbits.LATB1 = 1; 
    TRISBbits.TRISB1 = 0;
    SSP1CON1bits.SSPEN = 1;

//    initMAX7219(); 
//   RA6_SetHigh();
    //Solicita a fun��o controle
    ctrl();

    
    while (1)
    {

        

        v = ADC_GetConversion(channel_AN2); // Armazena o valor fornecido pelo conversor anal�gico para digital
        temperature = (int)((float)v*0.2); // Converte o valor para unidades de engenharia da temperatura
        speed = (int)(pulse/(((float)colect_value)*.000002))*4;// Converte o valor para unidades de engenharia da velocidade
        position = (pulse*pulses);  // Converte o valor para unidades de engenharia da posi��o
        
        // Verifica se esta pronto para leitura
        if(EUSART_is_rx_ready()){
            while(EUSART_is_rx_ready()){
            rxByte = EUSART_Read(); //Armazena o dado enviado
            floor_req = (int)(rxByte); // Transforma em inteiro e armazena na vari�vel
            
            }
            if(motor_state == 0){ // Verifica se estiv� parado
                ctrl();// Ativa o elevador
                //makeMatrix(); //Ativa o painel do elevador
            }
                

        }
        
        //Alegria... ou n�o
        // Add your application code
    }
}
/**
 End of File
*/